package com.number;

public class MultiplicationTable {
	
//	2*1=2
//	2*2=4
//	2*3=6     n=2   i=1 10
	
	public static void main(String[] args) {
		
		int n=2;
		
		for(int i=1;i<=10;i++) {
			
			System.out.println(n*i);
			
		}
		
		
	}

}
