package com.number;

public class FactorialOfN {
	
//	5! >> 1*2*3*4*5
	
	public static void main(String[] args) {
		
		int n=5;
		
		int fact=1;
		
		for(int i=1;i<=n;i++) {
			
//			fact=fact*i;
			fact*=i;
			
		}
		
		
		System.out.println(fact);
	}

}
