package com.number;

public class AdditionTillNth {
	
//	5 >> 1+2+3+4+5=15
	
	
	public static void main(String[] args) {
		
		int n=5;
		
		int sum=0;
		
		for(int i=n;i>=1;i--) {//0+5
			
//			sum=sum+i;
			sum +=i;
			
		}
		
		System.out.println(sum);
	}

}
