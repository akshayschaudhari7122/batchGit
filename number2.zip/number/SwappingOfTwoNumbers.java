package com.number;

public class SwappingOfTwoNumbers {
	
//	a=55
//	b=44
	
//	c=a;
//	a=b
//	b=c
	
	public static void main(String[] args) {
		
		int a=55,b=44,c;
		
		c=a;
		a=b;
		b=c;
		
		System.out.println("A : "+a+"\nB : " +b);
		
	}

}
