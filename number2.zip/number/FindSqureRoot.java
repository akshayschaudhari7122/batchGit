package com.number;

public class FindSqureRoot {
	
//	16 >> 2,4,8
	
	public static void main(String[] args) {
		
		int n=8;
		int r=3;
		
		for(int i=1;i<=n;i++) {
			
			if(n%i==0) {
				int power=1;
				
				for(int j=1;j<=r;j++) {
					
					power*=i;
					
				}
				
				if(n==power) {
					System.out.println(i);
					break;
				}
				
			}
			
		}
		
	}

}
