package com.number;

public class SwappingOfTwoNumbersWithotThirdVariable {

//	a=55
//	b=44

//	a=a+b   a=99 b=44
//	b=a-b   a=99 b=55
//	a=a-b   a=44 b=55

	public static void main(String[] args) {

		int a = 55, b = 44;

		a = a + b;
		b = a - b;
		a = a - b;

		System.out.println("A : " + a + "\nB : " + b);

	}

}
