package com.number;

public class LargestOfThree {
	
//	11 55 44
	
	public static void main(String[] args) {
		int a=11,b=55,c=44;
		
		if(a>b && a>c) {
			System.out.println("a");
		}else if(b>a && b>c) {
			System.out.println('b');
		}else {
			System.out.println('c');
		}
		
	}

}
