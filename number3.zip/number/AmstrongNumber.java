package com.number;

public class AmstrongNumber {
	
//	153 = 3
//	1^3 +5^3 +3^3=153

}
