package com.number;

public class ReverseNumber {
	
//	789 = 987
//	78  = 9
//	7=    8
	
	public static void main(String[] args) {
		
		int n=7;
		int rev=0;
		
		while(n>0) {
			
			int rem=n%10;//9  >> 8  >> 7
			rev=rev*10+rem;
			n/=10;
			
		}
		
		System.out.println(rev);
		
	}

}
