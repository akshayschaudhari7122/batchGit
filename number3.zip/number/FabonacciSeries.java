package com.number;

public class FabonacciSeries {
	
//	 0 1 1 2 3 5 8 13 .....
	
	public static void main(String[] args) {
		
		int f=0,s=1,t,count=2;
		
		int n=15;
		
		System.out.print(f+" , "+s);
		
		while(count<n) {
			
			t=f+s;
			System.out.print(" , "+t);
			f=s;
			s=t;
			
			count++;
		}
		
		
	}
	

}
