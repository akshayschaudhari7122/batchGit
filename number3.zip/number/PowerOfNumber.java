package com.number;

public class PowerOfNumber {
	
//	2^3 == 2*2*2
//	5^2 == 5*5
	
//	N P  .. I=1  P
	
	public static void main(String[] args) {
		int n=5;
		int p=3;
		
		int result=1;
		
		for(int i=1;i<=p;i++) {
			
//			result=result*n;
			result*=n;
			
		}
		
		System.out.println(Math.sqrt(25));
		
		System.out.println(result);
	}

}
