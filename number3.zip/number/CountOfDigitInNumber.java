package com.number;

public class CountOfDigitInNumber {
	
//	456987 =6
//	45698
//	4569
//	456
//	45
//	4
	
	public static void main(String[] args) {
		
		int n=456987;
		
		int count=0;
		
		while(n>0) {
//			n=n/10;
			n/=10;
			count++;
			
		}
		System.out.println(count);
		
		
	}

}
