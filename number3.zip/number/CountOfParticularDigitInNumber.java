package com.number;

public class CountOfParticularDigitInNumber {
	
//	1241251167 >> 4
	
	public static void main(String[] args) {
		
		int n=5;
		int check=1;
		
		int count=0;
		
		while(n>0) {
			
			int rem=n%10;
			n/=10;
			
			if(rem==check) {
				count++;
			}
			
			
		}
		System.out.println(count);
		
		
	}

}
