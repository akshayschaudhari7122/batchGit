package com.number;

public class DivisorOfNumber {
	
	public static void main(String[] args) {
		
		int n=55;
		
		for(int i=1;i<=n;i++) {
			
			if(n%i==0) {
				System.out.print(i+" ,");
			}
			
			
		}
		
	}

}
